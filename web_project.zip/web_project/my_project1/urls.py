"""
URL configuration for my_project1 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from my_project1.view import main,hey_man
from Comment import views

urlpatterns = [
    path('admin/', admin.site.urls), 
    path("",main),
    path("daum/",hey_man),
    path("comments/", views.comment_list, name="comment_list"),
    path('comments/<int:comment_id>/', views.get_comment, name='get_comment'),  # 댓글 로드
    path("comments/<int:comment_id>/edit/", views.comment_edit, name="comment_edit"),
     path("comments/<int:comment_id>/editable/", views.edit_comment, name="edit_comment"),
    path("comments/<int:comment_id>/validate_password/", views.validate_password, name="validate_password"),

]
